--- @meta

default_shadow = {}
